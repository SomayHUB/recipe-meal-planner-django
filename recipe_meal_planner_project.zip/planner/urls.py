from django.urls import path
from . import views

app_name = 'planner'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('recipes/', views.recipe_list, name='recipe_list'),
    path('recipes/add/', views.recipe_create, name='recipe_create'),
    path('recipes/<int:pk>/', views.recipe_detail, name='recipe_detail'),
    path('recipes/<int:pk>/edit/', views.recipe_update, name='recipe_update'),
    path('recipes/<int:pk>/delete/', views.recipe_delete, name='recipe_delete'),
    path('recipes/<int:pk>/favorite/', views.toggle_favorite, name='toggle_favorite'),
    path('planner/', views.meal_plan, name='meal_plan'),
    path('planner/add/', views.meal_plan_create, name='meal_plan_create'),
    path('planner/<int:pk>/delete/', views.meal_plan_delete, name='meal_plan_delete'),
    path('shopping-list/', views.shopping_list, name='shopping_list'),
]
